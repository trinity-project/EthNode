from typing import (
    NewType,
)

ContractName = NewType('ContractName', str)
URI = NewType('URI', str)
