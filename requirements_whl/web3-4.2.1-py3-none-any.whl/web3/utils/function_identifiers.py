class FallbackFn:
    pass
